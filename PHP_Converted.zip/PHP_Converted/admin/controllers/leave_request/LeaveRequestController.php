<?php
class LeaveRequestController extends Controller {

    public function __construct() {
        // Add auth/session checks if needed
    }

    // --- List All Leave Requests ---
    public function index() {
        view("leave_request");
    }
    // --- List All Leave Requests ---
   public function report() {
        view("leave_request_report");
    }

    // --- Show Create Form ---
    public function create() {
        view("leave_request");
    }

    // --- Save New Leave Request ---
    public function save($data, $file) {
        if(isset($data["create"])) {
            $errors = [];

            // You can add validation here if needed

            if(count($errors) == 0) {
                $leaverequest = new LeaveRequest();
                $leaverequest->emp_id = $data["emp_id"];
                $leaverequest->leave_type = $data["leave_type"];
                $leaverequest->from_date = $data["from_date"];
                $leaverequest->to_date = $data["to_date"];
                $leaverequest->total_days = $data["total_days"];
                $leaverequest->reason = $data["reason"];
                $leaverequest->status = $data["status"];
                $leaverequest->approved_by = $data["approved_by"];
                $leaverequest->paid_leave = $data["paid_leave"];
                $leaverequest->applied_time = date("Y-m-d H:i:s");
                $leaverequest->approved_time = date("Y-m-d H:i:s");

                // Handle attachment
                if(isset($file["attachment"]) && $file["attachment"]["name"] != "") {
                    $filename = time() . '_' . $file["attachment"]["name"];
                    move_uploaded_file($file["attachment"]["tmp_name"], "uploads/" . $filename);
                    $leaverequest->attachment = $filename;
                }

                $leaverequest->save();
                redirect("leaverequest");
            } else {
                print_r($errors);
            }
        }
    }

    // --- Show Edit Form ---
    public function edit($id) {
        $leaverequest = LeaveRequest::find($id);
        if(!$leaverequest) die("Leave Request not found!");
        view("leave_request", $leaverequest);
    }

    // --- Update Existing Leave Request ---
    public function update($data, $file) {
        if(isset($data["id"])) {
            $errors = [];

            if(count($errors) == 0) {
                // ✅ Create a new LeaveRequest object (model) instead of using stdClass
                $leaverequest = new LeaveRequest();
                $leaverequest->id = $data["id"];
                $leaverequest->emp_id = $data["emp_id"];
                $leaverequest->leave_type = $data["leave_type"];
                $leaverequest->from_date = $data["from_date"];
                $leaverequest->to_date = $data["to_date"];
                $leaverequest->total_days = $data["total_days"];
                $leaverequest->reason = $data["reason"];
                $leaverequest->status = $data["status"];
                $leaverequest->approved_by = $data["approved_by"];
                $leaverequest->paid_leave = $data["paid_leave"];
                $leaverequest->applied_time = $data["applied_time"] ?? date("Y-m-d H:i:s");
                $leaverequest->approved_time = $data["approved_time"] ?? date("Y-m-d H:i:s");

                // Handle new attachment
                if(isset($file["attachment"]) && $file["attachment"]["name"] != "") {
                    $filename = time() . '_' . $file["attachment"]["name"];
                    move_uploaded_file($file["attachment"]["tmp_name"], "uploads/" . $filename);
                    $leaverequest->attachment = $filename;
                } else {
                    // Keep old attachment if no new file uploaded
                    $leaverequest->attachment = $data["old_attachment"] ?? null;
                }

                $leaverequest->update(); // ✅ now it works
                redirect("leaverequest");
            } else {
                print_r($errors);
            }
        }
    }

    // --- Confirm/Delete Page ---
    public function confirm($id) {
        $leaverequest = LeaveRequest::find($id);
        if(!$leaverequest) die("Leave Request not found!");
        view("leave_request");
    }

    // --- Delete Leave Request ---
    public function delete($id) {
        LeaveRequest::delete($id);
        redirect("leaverequest");
    }

    // --- Show Single Record ---
    public function show($id) {
        $leaverequest = LeaveRequest::find($id);
        if(!$leaverequest) die("Leave Request not found!");
        view("leave_request", $leaverequest);
    }
}
?>
