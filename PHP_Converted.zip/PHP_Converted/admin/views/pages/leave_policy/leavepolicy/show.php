<?php
echo Page::title(["title"=>"Show LeavePolicy"]);
echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leavepolicy", "text"=>"Manage LeavePolicy"]);
echo Page::context_open();
echo LeavePolicy::html_row_details($id);
echo Page::context_close();
echo Page::body_close();
