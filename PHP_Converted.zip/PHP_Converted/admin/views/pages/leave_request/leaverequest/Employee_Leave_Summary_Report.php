<?php
echo Page::body_open();
echo Page::context_open();

global $db, $tx;

// Show summary only after Search
$showData = isset($_POST['search']);
?>

<!-- Page Title -->
<div class="text-center my-4">
    <h3 class="fw-bold text-primary mb-1">Employee Leave Summary</h3>
    <!-- <p class="text-muted small">Select filters to view summary of leaves</p> -->
</div>

<!-- Search Form + Summary Card -->
<div class="container-fluid px-4">
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
        <div class="card-header bg-gradient bg-primary text-white py-3">
            <h4 class="mb-0"><i class="bi bi-funnel-fill"></i>Monthly Leave Summary Report</h4>
        </div>

        <div class="card-body bg-light" style="background-color: #f8f9fa;">
            <!-- Search Form -->
            <form method="POST" class="row g-4 align-items-end border p-4 rounded-4 shadow-sm" style="background-color: #f8f9fa;">

                <!-- Month -->
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Month</label>
                    <select name="month" class="form-select" required>
                        <option value="">Select Month</option>
                        <?php
                        for ($m = 1; $m <= 12; $m++) {
                            $monthName = date("F", mktime(0, 0, 0, $m, 1));
                            $selected = (isset($_POST['month']) && $_POST['month'] == $m) ? "selected" : "";
                            echo "<option value='$m' $selected>$monthName</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Year -->
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Year</label>
                    <select name="year" class="form-select" required>
                        <option value="">Select Year</option>
                        <?php
                        for ($y = date("Y"); $y >= 2020; $y--) {
                            $selected = (isset($_POST['year']) && $_POST['year'] == $y) ? "selected" : "";
                            echo "<option value='$y' $selected>$y</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Employee -->
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Employee</label>
                    <select name="emp_id" class="form-select">
                        <option value="">All Employees</option>
                        <?php
                        $employees = [];
                        $empRes = $db->query("SELECT id, name FROM {$tx}employees ORDER BY name ASC");
                        while ($emp = $empRes->fetch_assoc()) {
                            $employees[$emp['id']] = $emp['name'];
                            $selected = (isset($_POST['emp_id']) && $_POST['emp_id'] == $emp['id']) ? "selected" : "";
                            echo "<option value='{$emp['id']}' $selected>{$emp['name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Search Button -->
                <div class="col-md-2">
                    <button type="submit" name="search" class="btn btn-lg btn-primary shadow-sm w-100 fw-semibold mt-2">
                        <i class="bi bi-search"></i> Leave Summary
                    </button>
                </div>
            </form>

            <?php
            if ($showData) {
                $month = intval($_POST['month']);
                $year = intval($_POST['year']);
                $emp_id = $_POST['emp_id'] ?? '';

                // Fetch employees (filter if specific employee selected)
                if(!empty($emp_id)) {
                    $employeesFiltered = [];
                    $empRes = $db->query("SELECT id, name FROM {$tx}employees WHERE id = '$emp_id'");
                    while($emp = $empRes->fetch_assoc()) {
                        $employeesFiltered[$emp['id']] = $emp['name'];
                    }
                } else {
                    $employeesFiltered = $employees;
                }

                // Prepare leave summary
                $summary = [];
                foreach ($employeesFiltered as $id => $name) {
                    $summary[$id] = [
                        'total' => 0,
                        'approved' => 0,
                        'pending' => 0,
                        'rejected' => 0,
                        'total_days' => 0,
                    ];

                    $leavesQuery = $db->query("SELECT status, total_days FROM {$tx}leave_request 
                        WHERE emp_id = '$id' AND MONTH(from_date) = '$month' AND YEAR(from_date) = '$year'");

                    while ($leave = $leavesQuery->fetch_assoc()) {
                        $summary[$id]['total'] += 1;
                        $summary[$id]['total_days'] += intval($leave['total_days']);
                        $status = strtolower($leave['status']);
                        if ($status == 'approved') $summary[$id]['approved'] += 1;
                        elseif ($status == 'pending') $summary[$id]['pending'] += 1;
                        elseif ($status == 'rejected') $summary[$id]['rejected'] += 1;
                    }
                }
            ?>

            <!-- Summary Table -->
            <div class="report-container mt-4" style="background-color: #f8f9fa; padding: 20px; border-radius: 15px;">
                <h5 class="text-primary fw-bold mb-3">
                    <i class="bi bi-card-list"></i> Leave Summary — <?php echo date("F", mktime(0,0,0,$month,1)) . " " . $year; ?>
                </h5>

                <div class="table-responsive">
                   <table class="table table-bordered align-middle text-center custom-table" style="background-color: #ffffff;">
    <thead style="background-color: #007bff; color: #ffffff;"> <!-- <-- change background color here -->
        <tr>
            <th>Employee</th>
            <th>Total Leaves</th>
            <th>Approved</th>
            <th>Pending</th>
            <th>Rejected</th>
            <th>Total Days</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($summary as $empId => $data): ?>
        <tr>
            <td class="fw-semibold"><?php echo htmlspecialchars($employeesFiltered[$empId]); ?></td>
            <td><?php echo $data['total']; ?></td>
            <td><?php echo $data['approved']; ?></td>
            <td><?php echo $data['pending']; ?></td>
            <td><?php echo $data['rejected']; ?></td>
            <td><?php echo $data['total_days']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

                </div>
            </div>

            <?php } else { ?>
                <div class="alert alert-info text-center rounded-3 shadow-sm mt-4">
                    <i class="bi bi-info-circle"></i> Please select filters and click <b>Show Summary</b>.
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php
echo Page::context_close();
echo Page::body_close();
?>
