<?php   
   //Remote
   
     define("SERVER","localhost");
     define("USER","root");
     define("DATABASE","hrm");
     define("PASSWORD","");


    $db=new mysqli(SERVER,USER,PASSWORD,DATABASE);
    $tx="";
  

?>